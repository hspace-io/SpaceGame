from pwn import *

p = process('./prob')
#p = remote('127.0.0.1', 21346)

CS = 1
DO = 2
HOLD = 3
WP = 4
VSS = 5
VCC1 = 6
VCC2 = 7
RP = 8
CLK = 9
DI = 10

def set_port(index, serial):
    p.sendlineafter(b'> ', b'1')
    p.sendlineafter(b'> ', str(index).encode())
    p.sendlineafter(b'> ', str(serial).encode())

set_port(CS, 15)
set_port(DO, 12)
set_port(VSS, 7)
set_port(VCC1, 2)
set_port(VCC2, 4)
set_port(RP, 3)
set_port(CLK, 11)
set_port(DI, 14)

#p.sendlineafter(b'> ', b'2')
#p.sendlineafter(b'> ', b'3')
#p.sendlineafter(b'> ', b'y')

p.interactive()
